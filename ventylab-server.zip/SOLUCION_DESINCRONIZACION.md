# 🔧 Solución: Error de Columna Inexistente en Prisma

## 🐛 Problema

El cliente Prisma está desincronizado con la base de datos. El error indica que Prisma está buscando una columna que no existe en la BD.

**Error típico:**
```
Unknown column 'exists' in 'field list'
```
o
```
Column 'X' does not exist in the current database schema
```

## ✅ Solución Rápida

### Opción 1: Script Automático (Recomendado)

Ejecuta el script que sincroniza todo automáticamente:

```powershell
cd c:\Marcela\TESIS\ventylab-server
.\fix-prisma-sync.ps1
```

Este script:
1. ✅ Limpia el caché de Prisma
2. ✅ Regenera el cliente Prisma
3. ✅ Sincroniza el schema con la BD
4. ✅ Valida el schema

### Opción 2: Pasos Manuales

Si prefieres hacerlo manualmente:

```powershell
cd c:\Marcela\TESIS\ventylab-server

# 1. Limpiar caché de Prisma
Remove-Item -Recurse -Force node_modules\.prisma -ErrorAction SilentlyContinue

# 2. Regenerar cliente Prisma
npx prisma generate

# 3. Sincronizar schema con la BD (sin perder datos)
npx prisma db push --accept-data-loss

# 4. Reiniciar el servidor
npm run dev
```

### Opción 3: Si hay datos importantes que preservar

Si necesitas preservar los datos y hay diferencias significativas:

```powershell
cd c:\Marcela\TESIS\ventylab-server

# 1. Limpiar caché
Remove-Item -Recurse -Force node_modules\.prisma -ErrorAction SilentlyContinue

# 2. Crear migración
npx prisma migrate dev --name sync_schema

# 3. Regenerar cliente
npx prisma generate

# 4. Reiniciar
npm run dev
```

## 🔍 Verificación

Después de ejecutar la solución, verifica:

1. **El servidor inicia sin errores:**
   ```powershell
   npm run dev
   ```

2. **No hay errores de columnas en la consola**

3. **Prisma Studio funciona:**
   ```powershell
   npx prisma studio
   ```

4. **El progreso se guarda correctamente:**
   - Entra a una lección
   - Avanza con "Siguiente"
   - Verifica en Network tab que la petición PUT a `/api/progress/lesson/:id` es exitosa

## 🚨 Si el Problema Persiste

### 1. Verificar el Schema

Asegúrate de que el schema en `prisma/schema.prisma` esté correcto:

```powershell
npx prisma validate
```

### 2. Verificar el Estado de la BD

Compara el schema con la BD actual:

```powershell
npx prisma db pull
```

Esto mostrará las diferencias entre el schema y la BD.

### 3. Resetear la BD (Solo en Desarrollo)

⚠️ **ADVERTENCIA:** Esto borra todos los datos.

```powershell
npx prisma migrate reset --force
npx prisma migrate dev --name init
npx prisma generate
```

### 4. Revisar Logs del Servidor

Si el error persiste, revisa los logs del servidor para ver exactamente qué columna está causando el problema:

```powershell
npm run dev
```

Busca en los logs mensajes como:
- `Unknown column`
- `Column does not exist`
- `Field does not exist`

## 📝 Prevención

Para evitar este problema en el futuro:

1. **Siempre ejecuta migraciones después de cambiar el schema:**
   ```powershell
   npx prisma migrate dev --name nombre_descriptivo
   ```

2. **Regenera el cliente después de cambios:**
   ```powershell
   npx prisma generate
   ```

3. **Usa el script de regeneración:**
   ```powershell
   .\regenerate-prisma.ps1
   ```

4. **Verifica antes de commitear:**
   ```powershell
   npx prisma validate
   npx prisma format
   ```

## 🔗 Archivos Relacionados

- `prisma/schema.prisma` - Schema de la base de datos
- `fix-prisma-sync.ps1` - Script de sincronización automática
- `regenerate-prisma.ps1` - Script de regeneración del cliente

## 💡 Notas

- El problema de "columna inexistente" generalmente ocurre cuando:
  - El schema cambió pero no se aplicó la migración
  - El cliente Prisma está desactualizado
  - Hay diferencias entre el schema y la BD

- `prisma db push` es más rápido pero menos seguro que `migrate dev`
- `migrate dev` crea un historial de migraciones que es mejor para producción
