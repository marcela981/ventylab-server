# VentyLab Progress System Analysis & Improvement Plan

## Executive Summary

After analyzing the codebase across both `ventylab-server` (backend) and `ventilab-web` (frontend), I've identified the root cause of progress synchronization issues and propose a targeted solution that improves the user experience without over-engineering.

---

## 1. Current Architecture Diagnosis

### 1.1 Prisma Schema (`prisma/schema.prisma`)

**Current Progress Model:**
```prisma
model Progress {
  id                   String    @id
  userId               String
  moduleId             String?   // For module-level tracking
  lessonId             String?   // For lesson-level tracking
  currentStep          Int       @default(0)
  totalSteps           Int       @default(1)
  completed            Boolean   @default(false)
  completionPercentage Float     @default(0)  // 0-100
  progress             Float     @default(0)  // Alias for compatibility
  timeSpent            Int       @default(0)  // seconds
  scrollPosition       Float?
  lastViewedSection    String?
  lastAccess           DateTime?
  completedAt          DateTime?
}
```

**Issues Identified:**
1. **Binary Module Progress** - Module progress is calculated by counting lessons with `progress === 100`, not by averaging lesson progress
2. **No Section-Level Granularity** - `lastViewedSection` exists but isn't used for progress calculation
3. **Step Tracking Underutilized** - `currentStep/totalSteps` could represent sections but isn't aligned with JSON structure

### 1.2 JSON Content Structure

```json
{
  "id": "module-02-ecuacion-movimiento",
  "sections": [
    { "id": "m2-intro-a", "order": 1, "type": "introduction", "estimatedTime": 8 },
    { "id": "m2-intro-b", "order": 2, "type": "introduction", "estimatedTime": 5 },
    // ... 20+ sections per lesson
  ]
}
```

**Key Insight:** Lessons behave like book chapters with many sections. A lesson like "Ecuación del Movimiento" has 20+ sections, yet progress only advances when ALL sections are complete.

### 1.3 Current Progress Calculation Logic

**File:** `src/utils/computeModuleProgress.ts`
```typescript
// A lesson is completed ONLY if progress === 100
const completedLessonsCount = lessons.filter(lesson => lesson.progress === 100).length;
const progressPercentage = Math.floor((completedLessonsCount / totalLessonsCount) * 100);
```

**The Problem:**
- Student reads 90% of a lesson → Lesson progress = 90%
- Module progress = 0% (because 90 ≠ 100)
- Student reads remaining 10% → Lesson progress = 100%
- Module progress jumps from 0% to 33% (for a 3-lesson module)

This creates a **jarring, non-continuous experience** that doesn't reflect learning effort.

---

## 2. Root Cause Analysis

### Primary Issue: Binary vs. Continuous Progress

```
CURRENT MODEL (Binary):
┌─────────────────────────────────────────────────────────────────┐
│ Module Progress = count(lessons where progress === 100) / total │
└─────────────────────────────────────────────────────────────────┘

Lesson 1: 90%  → Counts as 0
Lesson 2: 100% → Counts as 1
Lesson 3: 50%  → Counts as 0
───────────────────────────────
Module Progress = 1/3 = 33%

But perceived effort = (90 + 100 + 50) / 300 = 80% !
```

### Secondary Issues:

1. **Section Progress Not Tracked** - JSON has sections, but we don't track which sections are completed
2. **Frontend State Fragmentation** - Multiple sources (SWR, Context, localStorage) can be out of sync
3. **Optimistic Updates Not Propagating** - Lesson progress updates don't immediately reflect in module cards

---

## 3. Proposed Solution

### Philosophy: "Progress Should Reflect Learning Effort"

Instead of binary completion, module progress should represent the **weighted average of lesson progress**.

### 3.1 Option A: Continuous Module Progress (RECOMMENDED)

**Change `computeModuleProgress` to average lesson progress:**

```typescript
// NEW: Module progress = average of lesson progress values
export function computeModuleProgress(lessons: LessonProgressInput[]): ModuleProgressResult {
  if (!lessons || lessons.length === 0) {
    return { completedLessonsCount: 0, totalLessonsCount: 0, progressPercentage: 0 };
  }

  const totalLessonsCount = lessons.length;

  // Count completed lessons (progress === 100)
  const completedLessonsCount = lessons.filter(l => l.progress === 100).length;

  // Calculate average progress across all lessons
  const totalProgress = lessons.reduce((sum, l) => sum + (l.progress ?? 0), 0);
  const averageProgress = totalProgress / totalLessonsCount;

  // Round down to avoid showing 100% before actual completion
  const progressPercentage = Math.floor(averageProgress);

  return {
    completedLessonsCount,
    totalLessonsCount,
    progressPercentage,
  };
}
```

**Impact:**
```
Lesson 1: 90%
Lesson 2: 100%
Lesson 3: 50%
───────────────────────────────
NEW Module Progress = floor((90 + 100 + 50) / 3) = 80%
```

**Advantages:**
- Continuous, motivating progress
- No schema changes required
- Backward compatible
- Reflects learning effort

### 3.2 Option B: Section-Level Tracking (MORE GRANULAR)

If finer control is needed, track sections explicitly:

**Schema Addition:**
```prisma
model Progress {
  // ... existing fields
  completedSections    String[]  @default([])  // Array of section IDs
  totalSections        Int       @default(0)
}
```

**Lesson Progress Calculation:**
```typescript
lessonProgress = (completedSections.length / totalSections) * 100
```

**Advantages:**
- Precise tracking of which sections were read
- Can resume exactly where user left off
- Enables "next unread section" feature

**Disadvantages:**
- More complex migration
- Requires frontend to send section IDs on completion

---

## 4. Recommended Implementation Plan

### Phase 1: Fix Module Progress Calculation (Backend)

**File:** `src/utils/computeModuleProgress.ts`

```typescript
/**
 * computeModuleProgress - Single source of truth for module progress calculation
 *
 * UPDATED RULES:
 * - Module progress = average of lesson progress values (0-100)
 * - A lesson is "completed" when progress === 100
 * - Progress percentage is rounded DOWN to avoid false completion
 */
export function computeModuleProgress(lessons: LessonProgressInput[]): ModuleProgressResult {
  if (!lessons || !Array.isArray(lessons) || lessons.length === 0) {
    return {
      completedLessonsCount: 0,
      totalLessonsCount: 0,
      progressPercentage: 0,
    };
  }

  const totalLessonsCount = lessons.length;

  // Count lessons where progress === 100 (fully completed)
  const completedLessonsCount = lessons.filter(lesson => {
    const progress = typeof lesson.progress === 'number' ? lesson.progress : 0;
    return progress === 100;
  }).length;

  // NEW: Calculate average progress across all lessons
  const totalProgress = lessons.reduce((sum, lesson) => {
    const progress = typeof lesson.progress === 'number' ? lesson.progress : 0;
    return sum + Math.min(100, Math.max(0, progress)); // Clamp to 0-100
  }, 0);

  // Average progress (continuous)
  const averageProgress = totalProgress / totalLessonsCount;

  // Round down to prevent showing 100% before all lessons are complete
  // Also ensure we don't show 100% unless ALL lessons are actually complete
  let progressPercentage = Math.floor(averageProgress);

  // Safety: Only show 100% if all lessons are truly complete
  if (progressPercentage === 100 && completedLessonsCount < totalLessonsCount) {
    progressPercentage = 99;
  }

  return {
    completedLessonsCount,
    totalLessonsCount,
    progressPercentage,
  };
}
```

### Phase 2: Update Backend Services

**Files to update:**
- `src/services/progress.service.ts` - Uses computeModuleProgress (already does)
- `src/services/progress/moduleProgress.service.ts` - Uses computeModuleProgress (already does)
- `src/services/progress/progressQuery.service.ts` - Uses computeModuleProgress (already does)

No changes needed - they all use `computeModuleProgress` as the single source of truth.

### Phase 3: Add Level Progress Aggregation (Backend)

Create a new function for level progress:

**File:** `src/utils/computeLevelProgress.ts`

```typescript
export interface ModuleProgressInput {
  id: string;
  progress: number; // 0-100
}

export interface LevelProgressResult {
  completedModulesCount: number;
  totalModulesCount: number;
  progressPercentage: number;
}

/**
 * Compute level progress from module progress values
 * Uses the same averaging logic as module progress
 */
export function computeLevelProgress(modules: ModuleProgressInput[]): LevelProgressResult {
  if (!modules || modules.length === 0) {
    return {
      completedModulesCount: 0,
      totalModulesCount: 0,
      progressPercentage: 0,
    };
  }

  const totalModulesCount = modules.length;

  // Count completed modules (progress === 100)
  const completedModulesCount = modules.filter(m => m.progress === 100).length;

  // Calculate average progress
  const totalProgress = modules.reduce((sum, m) => sum + (m.progress ?? 0), 0);
  const averageProgress = totalProgress / totalModulesCount;

  let progressPercentage = Math.floor(averageProgress);

  // Only show 100% if all modules are complete
  if (progressPercentage === 100 && completedModulesCount < totalModulesCount) {
    progressPercentage = 99;
  }

  return {
    completedModulesCount,
    totalModulesCount,
    progressPercentage,
  };
}
```

### Phase 4: Frontend Synchronization

**Key Changes in `LearningProgressContext`:**

1. **Single Source of Truth:** Use `moduleProgressAggregated` computed from lesson progress
2. **Remove Redundant Fetches:** Deprecate `useModuleProgress` SWR hook in favor of context
3. **Propagate Updates:** When lesson progress changes, immediately recompute module progress

```javascript
// In LearningProgressContext.jsx

// Compute module progress using same logic as backend
const computeModuleProgressFromLessons = useCallback((lessonsById) => {
  const lessons = Object.values(lessonsById || {});
  if (lessons.length === 0) return 0;

  const totalProgress = lessons.reduce((sum, l) => sum + (l.progress ?? 0), 0);
  const averageProgress = totalProgress / lessons.length;

  return Math.floor(averageProgress);
}, []);

// Update moduleProgressAggregated whenever progressByModule changes
useEffect(() => {
  const newModuleProgress = {};

  for (const [moduleId, moduleData] of Object.entries(progressByModule)) {
    const lessonsById = moduleData?.lessonsById || {};
    const lessons = Object.values(lessonsById);

    const completedLessons = lessons.filter(l => l.progress === 100).length;
    const progress = computeModuleProgressFromLessons(lessonsById);

    newModuleProgress[moduleId] = {
      progress: progress / 100, // Store as 0-1 for consistency
      progressPercent: progress,
      completedLessons,
      totalLessons: lessons.length,
      isCompleted: progress === 100 && completedLessons === lessons.length,
    };
  }

  setModuleProgressAggregated(newModuleProgress);
}, [progressByModule]);
```

### Phase 5: Progress Bar Components

Ensure all progress bars read from the same source:

```jsx
// ModuleCard.jsx
const { moduleProgressAggregated } = useLearningProgress();
const moduleProgress = moduleProgressAggregated[module.id];

return (
  <LinearProgress
    variant="determinate"
    value={moduleProgress?.progressPercent ?? 0}
  />
);
```

---

## 5. Progress Formulas Summary

### Lesson Progress
```
lessonProgress = (sectionsRead / totalSections) * 100
             OR = scroll-based percentage from frontend
             OR = (currentStep / totalSteps) * 100
```

### Module Progress (NEW - Continuous)
```
moduleProgress = average(lessonProgress for all lessons in module)
               = sum(lessonProgress) / totalLessons
               = floor(average) to avoid premature 100%
```

### Level Progress
```
levelProgress = average(moduleProgress for all modules in level)
              = sum(moduleProgress) / totalModules
```

### Completion Flags
```
lessonCompleted = lessonProgress === 100
moduleCompleted = ALL lessons have progress === 100
levelCompleted = ALL modules have progress === 100
```

---

## 6. Edge Cases Handled

| Scenario | Current Behavior | New Behavior |
|----------|------------------|--------------|
| 0 lessons with progress | 0% | 0% |
| 1 lesson at 50% | 0% | 50% |
| 2 lessons: 100%, 0% | 50% | 50% |
| 3 lessons: 100%, 100%, 90% | 66% | 96% → caps at 99% |
| All lessons at 100% | 100% | 100% |
| Lesson with no sections | Undefined | Default to 0 or 100 based on `completed` flag |

---

## 7. Migration Strategy

### Step 1: Update Backend (No Schema Changes)
1. Modify `computeModuleProgress.ts` to use averaging
2. Test with existing data
3. Deploy

### Step 2: Update Frontend
1. Ensure `LearningProgressContext` uses same averaging formula
2. Remove/deprecate `useModuleProgress` SWR hook
3. Update all progress bar components to use context

### Step 3: Optional - Section Tracking
If section-level precision is needed later:
1. Add `completedSections: String[]` to Prisma schema
2. Update frontend to send section IDs on scroll
3. Calculate lesson progress from sections

---

## 8. Testing Checklist

- [ ] Lesson at 50% shows 50% on lesson card
- [ ] Module with 1 lesson at 50% shows 50% on module card
- [ ] Module with 3 lessons (100%, 50%, 0%) shows 50% on module card
- [ ] Completing a section immediately updates module card
- [ ] Level progress reflects average of module progress
- [ ] Progress never shows 100% unless all items are truly complete
- [ ] Offline changes sync correctly when back online
- [ ] Progress persists after page refresh

---

## 9. Files to Modify

### Backend (`ventylab-server`)
1. `src/utils/computeModuleProgress.ts` - Update formula
2. `src/utils/computeLevelProgress.ts` - Create new file
3. No schema changes required

### Frontend (`ventilab-web`)
1. `src/contexts/LearningProgressContext.jsx` - Update aggregation logic
2. `src/features/teaching/components/curriculum/ModuleCard/ModuleCard.jsx` - Use context
3. `src/components/LessonProgressBar.tsx` - Ensure consistency
4. `src/hooks/useModuleProgress.ts` - Deprecate or remove

---

## 10. Summary

**Root Cause:** Binary lesson completion model doesn't reflect continuous learning effort.

**Solution:** Change module progress from `count(completed) / total` to `average(progress)`.

**Impact:**
- More motivating user experience
- Progress feels continuous and rewarding
- No breaking changes to schema
- Backward compatible with existing data

**Effort Estimate:** 2-4 hours for backend + frontend changes.
