# Module Rendering Fix - module-01-inversion-fisiologica

## Problem Summary
The module card for "module-01-inversion-fisiologica" was not rendering in the Beginner Level view.

## Root Cause Analysis

### Primary Issue
The module `module-01-inversion-fisiologica` was defined in `src/config/curriculumData.ts` with an explicit ID, but:

1. **Database Module Missing**: The module did not exist in the PostgreSQL database with the matching ID
2. **No Lessons Imported**: Even if the module existed, it had no lessons in the database
3. **Frontend Filtering**: The frontend was likely filtering out modules where `lessonCount === 0` or `dbModule === undefined`

### Why This Happened
- The Prisma schema uses `@id @default(cuid())` which generates auto IDs
- The curriculum system uses **explicit IDs** like `'module-01-inversion-fisiologica'`
- Without proper seeding or importing, the module existed only in curriculum config but not in DB

## Solution Implemented

### 1. Backend Changes - Curriculum Service
**File**: `src/services/curriculum/index.ts`

Added a `status` object to each module response:

```typescript
status: {
  existsInDb: boolean;    // Module exists in database
  hasLessons: boolean;    // Module has lessons (lessonCount > 0)
  isAvailable: boolean;   // Ready to start (exists, has lessons, not locked)
  needsImport: boolean;   // Needs to be imported via import service
}
```

**IMPORTANT**: Modules are ALWAYS returned, regardless of database state. The `status` field is for UI hints only.

### 2. Seed Script Updated
**File**: `prisma/seed.ts`

Creates all curriculum modules with their explicit IDs:
- 6 Beginner modules
- 2 Prerequisitos modules

Run with:
```bash
npx prisma db seed
```

### 3. Sample Module JSON Created
**File**: `content/modules/module-01-inversion-fisiologica.json`

Demonstrates the correct `lessons[] → steps[]` structure for importing.

## Required Structure - IMPORTANT

ALL modules now use the **OFFICIAL** structure:

```
Module
 └── lessons[]   ← REQUIRED (array of lessons)
      └── steps[] ← REQUIRED (array of steps per lesson)
```

The legacy `sections[]` format is **NO LONGER SUPPORTED** for new content.

### Lesson JSON Structure
```json
{
  "id": "module-01-inversion-fisiologica",
  "title": "Inversión Fisiológica",
  "lessons": [
    {
      "id": "lesson-01-introduccion",
      "title": "Introducción",
      "steps": [
        {
          "id": "step-01",
          "type": "content",
          "title": "Step Title",
          "content": {
            "markdown": "Content here..."
          }
        }
      ]
    }
  ]
}
```

## Steps to Fix the Module

### Step 1: Run Database Seed
```bash
npx prisma db seed
```

This creates the module records in the database with the correct IDs.

### Step 2: Import Module Content
Use the import API to add lesson content:

```bash
curl -X POST http://localhost:3000/api/modules/import \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d @content/modules/module-01-inversion-fisiologica.json
```

Or use the import endpoint with the JSON body directly.

### Step 3: Verify Module Status
```bash
curl http://localhost:3000/api/modules/import-status/module-01-inversion-fisiologica \
  -H "Authorization: Bearer YOUR_TOKEN"
```

Expected response when properly imported:
```json
{
  "exists": true,
  "moduleTitle": "Inversión Fisiológica",
  "lessonCount": 2,
  "isActive": true
}
```

## Frontend Requirements

The frontend MUST:

1. **Always render all modules** returned by the curriculum API
2. Use the `status` field for UI hints:
   - `status.needsImport === true` → Show "Coming Soon" or placeholder
   - `status.isAvailable === false` → Show locked state or disabled card
3. **Never filter** modules based on `lessonCount === 0`
4. Show modules even when `progress === undefined`

### Example Frontend Logic
```typescript
// BAD - Don't filter modules
const visibleModules = modules.filter(m => m.lessonCount > 0); // WRONG!

// GOOD - Show all modules with appropriate states
const renderModule = (module) => {
  if (module.status.needsImport) {
    return <ModuleCard status="coming-soon" />;
  }
  if (module.isLocked) {
    return <ModuleCard status="locked" />;
  }
  return <ModuleCard status="available" />;
};
```

## API Response Format

### GET /api/curriculum/beginner

```json
{
  "success": true,
  "data": {
    "level": "beginner",
    "modules": [
      {
        "id": "module-01-inversion-fisiologica",
        "order": 1,
        "title": "Inversión Fisiológica",
        "description": "...",
        "isLocked": false,
        "lessonCount": 2,
        "status": {
          "existsInDb": true,
          "hasLessons": true,
          "isAvailable": true,
          "needsImport": false
        },
        "progress": {
          "completed": false,
          "completionPercentage": 25,
          "timeSpent": 300
        }
      }
    ],
    "totalModules": 6,
    "completedModules": 0,
    "levelProgress": 0
  }
}
```

## Validation Checklist

After implementing the fix, verify:

- [ ] Module card is visible in Beginner Level view
- [ ] Title "Inversión Fisiológica" is displayed
- [ ] Progress shows 0% initially (or actual progress if exists)
- [ ] Clicking the card opens Lesson 1
- [ ] All 6 beginner modules are shown (not just imported ones)

## Files Changed

1. `src/services/curriculum/index.ts` - Added status field to module response
2. `prisma/seed.ts` - Complete seed script for curriculum modules
3. `content/modules/module-01-inversion-fisiologica.json` - Sample module content
4. `FIX_MODULE_RENDERING.md` - This documentation

## Confirmation

The `lessons[]` structure is now the **ONLY** required structure for modules:

- `sections[]` - DEPRECATED, only for backward compatibility
- `lessons[] → steps[]` - REQUIRED for all new content

This is enforced by:
- Import service validation (`src/services/modules/import.service.ts`)
- Lesson content validation (`src/services/lessons/index.ts`)
- Module content parser (`src/utils/moduleContentParser.ts`)
