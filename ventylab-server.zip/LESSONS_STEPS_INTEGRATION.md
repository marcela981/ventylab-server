# Lessons → Steps JSON Structure Integration

## Summary of Changes

This document describes the backend changes made to support the new module JSON structure with `lessons[]` → `steps[]` hierarchy.

## JSON Structure Evolution

### Old Format (Legacy - Still Supported)
```json
{
  "type": "lesson",
  "sections": [
    { "type": "content", "data": {...} },
    { "type": "introduction", "data": {...} }
  ]
}
```

### New Format (Primary)
```json
{
  "id": "module-01-inversion-fisiologica",
  "moduleId": "module-01-fundamentals",
  "lessons": [
    {
      "id": "chapter-01-introduccion",
      "lessonId": "ch01",
      "order": 1,
      "title": "Introducción y Orientación",
      "steps": [
        {
          "id": "page-ch01-01",
          "stepId": "ch01-p01",
          "order": 1,
          "type": "introduction",
          "title": "Mapa del módulo",
          "content": { "markdown": "..." },
          "estimatedTime": 8
        }
      ]
    }
  ]
}
```

## Progress Tracking Hierarchy

The progress system now follows this hierarchy:

```
Level Progress = average(Module Progress values)
  └── Module Progress = average(Lesson Progress values)
       └── Lesson Progress = (currentStep / totalSteps) × 100
            └── Step Progress = completed or not
```

### Key Rules:
1. **Step completion** → updates Lesson progress (currentStep++)
2. **Lesson progress** → contributes to Module progress (average)
3. **Module progress** → contributes to Level progress (average)
4. A lesson is "completed" ONLY when `progress === 100`
5. A module is "completed" ONLY when ALL lessons have `progress === 100`

## Backend Files Changed

### 1. `src/services/lessons/index.ts`
- **`normalizeContentFormat()`** - New function to handle both `sections[]` and `steps[]`
- **`calculatePageCount()`** - Updated to support both formats
- **`getTotalStepCount()`** - New function for total step count
- **`validateLessonContent()`** - Updated to accept new format
- **`getLessonById()`** - Fixed to use `Progress` model, includes `totalSteps`
- **`markLessonAsCompleted()`** - Rewritten to use `Progress` model
- **`recordLessonAccess()`** - Rewritten to use `Progress` model
- **`deleteLesson()`** - Fixed to delete from `Progress` table

### 2. `src/services/modules/index.ts`
- **`getModuleById()`** - Rewritten to fetch progress separately
- **`getModuleLessons()`** - Rewritten to include lesson progress
- **`getUserModuleProgress()`** - Rewritten to use `Progress` model

### 3. `src/services/progress.service.ts`
- Added automatic module progress update when lesson progress changes
- Imports `calculateAndSaveModuleProgress` from moduleProgress service

### 4. New Utility Files
- **`src/utils/computeLessonProgress.ts`** - Lesson progress calculation utilities
- **`src/utils/moduleContentParser.ts`** - Module JSON parsing utilities

## API Response Changes

### GET /api/lessons/:id
Now includes:
```json
{
  "id": "lesson-id",
  "title": "Lesson Title",
  "content": "JSON content string",
  "pageCount": 5,      // Content pages (excluding intro/completion)
  "totalSteps": 7,     // All steps (for progress tracking)
  "module": {...},
  "progress": {
    "id": "progress-id",
    "currentStep": 3,
    "totalSteps": 7,
    "completionPercentage": 42,
    "completed": false,
    "timeSpent": 300,
    "lastAccess": "2026-01-26T...",
    "scrollPosition": 0.5,
    "lastViewedSection": "step-3"
  }
}
```

### GET /api/modules/:id/lessons
Now includes:
```json
[
  {
    "id": "lesson-1",
    "title": "Lesson 1",
    "order": 1,
    "pageCount": 5,
    "progress": {
      "currentStep": 5,
      "totalSteps": 5,
      "completionPercentage": 100,
      "completed": true,
      "timeSpent": 600,
      "lastAccess": "2026-01-26T..."
    }
  }
]
```

### PUT /api/progress/lesson/:id
Request body:
```json
{
  "currentStep": 3,
  "totalSteps": 7,
  "completionPercentage": 42,
  "timeSpent": 30,           // seconds to add
  "scrollPosition": 0.5,      // optional
  "lastViewedSection": "step-3", // optional
  "completed": false          // explicit - never auto-completes
}
```

## Frontend Integration Guide

### 1. Parsing Lesson Content
The frontend should use the `normalizeContentFormat()` logic:

```typescript
function parseContent(content: string | object) {
  const parsed = typeof content === 'string' ? JSON.parse(content) : content;

  // New format: steps[]
  if (Array.isArray(parsed.steps) && parsed.steps.length > 0) {
    return { items: parsed.steps, format: 'steps' };
  }

  // Legacy format: sections[]
  if (Array.isArray(parsed.sections) && parsed.sections.length > 0) {
    return { items: parsed.sections, format: 'sections' };
  }

  return null;
}
```

### 2. Rendering Steps
```typescript
// Get steps from lesson content
const { items: steps } = parseContent(lesson.content);

// Render each step
steps.forEach((step, index) => {
  const isExcluded = ['intro', 'introduction', 'completion', 'complete',
                      'conditional', 'navigation', 'redirect', 'summary']
                     .includes(step.type?.toLowerCase());

  // Count for progress should include ALL steps
  // Page count (visible pages) excludes intro/completion types
});
```

### 3. Updating Progress
```typescript
// When user advances to next step
async function updateProgress(lessonId: string, currentStep: number, totalSteps: number) {
  const response = await fetch(`/api/progress/lesson/${lessonId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      currentStep,
      totalSteps,
      completionPercentage: Math.round((currentStep / totalSteps) * 100),
      timeSpent: secondsOnCurrentStep,
      // Only set completed=true when explicitly marking as done
      completed: currentStep === totalSteps ? true : undefined
    })
  });

  // The backend will automatically update module progress
}
```

### 4. Displaying Progress
```typescript
// Module card
const moduleProgress = module.userProgress?.moduleProgress?.completionPercentage ?? 0;

// Lesson list
const lessonProgress = lesson.progress?.completionPercentage ?? 0;
const isLessonComplete = lessonProgress === 100;

// Level progress
const levelProgress = computeLevelProgress(moduleProgressValues);
```

## Database Schema (No Changes Required)

The existing `Progress` model handles everything:
```prisma
model Progress {
  id                   String    @id @default(cuid())
  userId               String
  moduleId             String?   // For module-level tracking
  lessonId             String?   // For lesson-level tracking
  currentStep          Int       @default(0)
  totalSteps           Int       @default(1)
  completed            Boolean   @default(false)
  completionPercentage Float     @default(0)
  progress             Float     @default(0)
  timeSpent            Int       @default(0)
  scrollPosition       Float?
  lastViewedSection    String?
  lastAccess           DateTime?
  completedAt          DateTime?
  // ...
}
```

## Backward Compatibility

1. **Old `sections[]` format** - Still fully supported via `normalizeContentFormat()`
2. **Progress calculations** - Same formulas, now applied to steps instead of sections
3. **API contracts** - Response structure enhanced but not breaking

## Testing Checklist

- [ ] Lesson with `steps[]` format renders correctly
- [ ] Lesson with `sections[]` format still renders correctly
- [ ] Progress updates when advancing through steps
- [ ] Module progress updates automatically when lesson progress changes
- [ ] Lesson shows 100% only when all steps complete
- [ ] Module shows 100% only when all lessons complete
- [ ] Resume point correctly identifies next incomplete lesson
- [ ] Navigation between lessons works correctly
