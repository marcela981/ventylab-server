# Guía: Resolver error "The column `existe` does not exist"

## Diagnóstico

- **Schema actual**: El modelo `Lesson` tiene `isActive` (no `existe`)
- **Migraciones**: Ninguna migración toca la columna `existe` en `lessons`
- **Origen probable**: Desalineación entre Prisma Client, base de datos o Prisma Studio

## Plan de corrección

### Antes de empezar

1. **Cierra todos los procesos** que usen Prisma o la base de datos:
   - Prisma Studio
   - `npm run dev` / servidor backend
   - Cualquier proceso que tenga abierto el proyecto

### Opción A: Desarrollo (puedes borrar datos) — recomendada

```powershell
cd c:\Marcela\TESIS\ventylab-server

# 1. Reset completo: schema + migraciones + seed
npx prisma migrate reset --force

# 2. Regenerar cliente
npx prisma generate

# 3. Probar backend
npm run dev
```

### Opción B: Conservar datos

```powershell
cd c:\Marcela\TESIS\ventylab-server

# 1. Aplicar migraciones pendientes
npx prisma migrate deploy

# 2. Forzar alineación schema ↔ DB (sin reset)
npx prisma db push

# 3. Limpiar caché y regenerar cliente
Remove-Item -Recurse -Force node_modules\.prisma -ErrorAction SilentlyContinue
npx prisma generate

# 4. Probar backend
npm run dev
```

### Opción C: Usar script existente

```powershell
cd c:\Marcela\TESIS\ventylab-server
.\fix-prisma-sync.ps1
```

## Si el error solo ocurre en Prisma Studio

1. Cierra Prisma Studio.
2. Ejecuta `npx prisma generate`.
3. Vuelve a abrir Prisma Studio: `npx prisma studio`.

## Verificar la base de datos

Para ver las columnas reales de `lessons`:

```sql
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'lessons' 
ORDER BY ordinal_position;
```

## Después de corregir

1. Prueba solo el backend: `npm run dev`
2. Prueba endpoint de lecciones (por ejemplo `GET /api/lessons` o la ruta que uses)
3. Prueba Prisma Studio si lo usas
4. Luego prueba frontend y dashboard
