// TODO: Implementar ResponseParser si es necesario
// Este archivo está pendiente de implementación

export class ResponseParser {
  // TODO: Implementar parsing de respuestas de IA
}

export default ResponseParser;

