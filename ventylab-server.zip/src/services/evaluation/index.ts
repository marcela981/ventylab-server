// Exportar servicio de evaluación

export * from './evaluation.service';
export * from '../../types/evaluation';

