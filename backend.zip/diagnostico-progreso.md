# 🔬 Diagnóstico Completo: Sistema de Progreso VentyLab

## 📋 Resumen Ejecutivo

El sistema de progreso tiene **5 problemas principales interconectados** que impiden que funcione correctamente:

| # | Problema | Severidad | Impacto |
|---|----------|-----------|---------|
| 1 | Error `trust proxy` en express-rate-limit | 🔴 Crítico | Servidor puede fallar |
| 2 | Rutas 404 (`/milestones`, `/achievements`, `/skills`) | 🟡 Medio | Frontend muestra errores |
| 3 | Schema de Prisma incompleto | 🔴 Crítico | BD no puede guardar progreso |
| 4 | Constraint names incorrectos en upsert | 🔴 Crítico | Queries fallan |
| 5 | Frontend no envía actualizaciones | 🔴 Crítico | Progreso no se persiste |

---

## 🐛 Problema 1: Error `trust proxy`

### Síntoma
```
ValidationError: The Express 'trust proxy' setting is true, which allows 
anyone to trivially bypass IP-based rate limiting.
```

### Causa
En `backend/src/index.ts` tienes `app.set('trust proxy', true)` pero express-rate-limit v7+ rechaza esta configuración por seguridad.

### Solución
Cambiar la configuración en `backend/src/index.ts`:

```typescript
// ANTES (inseguro):
app.set('trust proxy', true);

// DESPUÉS (seguro):
app.set('trust proxy', 1); // Solo confiar en el primer proxy
```

Y actualizar los limiters en `backend/src/middleware/rateLimiter.ts`:

```typescript
import rateLimit from 'express-rate-limit';

export const readLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  // Agregar esto para evitar el error:
  validate: { trustProxy: false }
});

export const writeLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false }
});
```

---

## 🐛 Problema 2: Rutas 404

### Síntoma
```
GET /api/progress/milestones 404
GET /api/progress/achievements 404
GET /api/progress/skills 404
```

### Causa
El frontend está llamando a rutas que no existen en el backend.

### Solución
**Opción A (Recomendada para deadline cercano):** Crear stubs en el backend que retornan arrays vacíos.

Agregar en `backend/src/routes/progress.ts`:

```typescript
// Stubs temporales para rutas que el frontend espera
router.get('/milestones', progressController.getMilestones);
router.get('/achievements', progressController.getAchievements);
router.get('/skills', progressController.getSkills);
```

Agregar en `backend/src/controllers/progress.controller.ts`:

```typescript
// Stubs - TODO: Implementar cuando haya tiempo
export async function getMilestones(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = req.headers['x-user-id'] as string || (req.user as any)?.id;
    if (!userId) return res.status(401).json({ error: 'Usuario no autenticado' });
    
    // Retornar array vacío por ahora
    res.json({ milestones: [], total: 0 });
  } catch (error) {
    next(error);
  }
}

export async function getAchievements(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = req.headers['x-user-id'] as string || (req.user as any)?.id;
    if (!userId) return res.status(401).json({ error: 'Usuario no autenticado' });
    
    res.json({ achievements: [], total: 0 });
  } catch (error) {
    next(error);
  }
}

export async function getSkills(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = req.headers['x-user-id'] as string || (req.user as any)?.id;
    if (!userId) return res.status(401).json({ error: 'Usuario no autenticado' });
    
    res.json({ skills: [], total: 0 });
  } catch (error) {
    next(error);
  }
}
```

**Opción B:** Remover las llamadas del frontend si no son necesarias.

---

## 🐛 Problema 3: Schema de Prisma Incompleto

### Síntoma
El servicio `progressUpdate.service.ts` intenta usar columnas que no existen:
- `progress` (usa `completionPercentage`)
- `moduleId` (no existe en Progress)
- `scrollPosition` (no existe)
- `lastViewedSection` (no existe)

### Causa
El schema de `Progress` no tiene todas las columnas que los servicios intentan usar.

### Solución
Actualizar `prisma/schema.prisma`:

```prisma
model Progress {
  id                   String    @id @default(cuid())
  userId               String
  moduleId             String?   // NUEVO: Para tracking a nivel módulo
  lessonId             String?   // Ahora opcional, puede ser progreso de módulo
  currentStep          Int       @default(0)
  totalSteps           Int       @default(1)
  completed            Boolean   @default(false)
  completionPercentage Float     @default(0)
  progress             Float     @default(0)  // NUEVO: Alias para compatibilidad
  timeSpent            Int       @default(0)
  scrollPosition       Float?    // NUEVO: Posición de scroll
  lastViewedSection    String?   // NUEVO: Última sección vista
  lastAccess           DateTime?
  completedAt          DateTime?
  createdAt            DateTime  @default(now())
  updatedAt            DateTime  @updatedAt

  user User @relation(fields: [userId], references: [id], onDelete: Cascade)

  // Constraints nombrados explícitamente
  @@unique([userId, lessonId], name: "progress_user_lesson_unique")
  @@unique([userId, moduleId], name: "progress_user_module_unique")
  @@index([userId])
  @@index([lessonId])
  @@index([moduleId])
  @@map("progress")
}
```

Ejecutar migración:
```bash
cd ventylab-server
npx prisma migrate dev --name add_progress_fields
npx prisma generate
```

---

## 🐛 Problema 4: Constraint Names Incorrectos

### Síntoma
El código usa:
```typescript
where: {
  progress_user_lesson_unique: { userId, lessonId },
}
```

Pero Prisma genera el constraint con otro nombre por defecto.

### Solución
Ya incluida en el Problema 3: nombrar explícitamente los constraints en el schema.

Luego en los servicios:
```typescript
// CORRECTO después de actualizar el schema:
const progress = await prisma.progress.upsert({
  where: {
    progress_user_lesson_unique: { userId, lessonId },
  },
  update: { ... },
  create: { ... },
});
```

---

## 🐛 Problema 5: Frontend No Envía Actualizaciones

### Síntoma
Al navegar por secciones con "Siguiente", el progreso no se guarda en la BD.

### Causa
El componente `LessonViewer.jsx` navega entre secciones pero no llama a la API.

### Solución
En `LessonViewer.jsx`, agregar llamada a la API cuando el usuario avanza:

```jsx
// Importar el hook o servicio
import { useUpdateLessonProgress } from '@/hooks/useProgress';
// O
import { updateLessonProgress } from '@/services/progressService';

// Dentro del componente:
const handleNextSection = async () => {
  const newIndex = currentSectionIndex + 1;
  setCurrentSectionIndex(newIndex);
  
  // Calcular progreso
  const totalSections = lesson.sections.length;
  const completionPercentage = Math.round((newIndex / totalSections) * 100);
  
  // Guardar progreso en backend
  try {
    await updateLessonProgress({
      lessonId: lessonId,
      completionPercentage,
      timeSpent: 60, // o calcular tiempo real
    });
  } catch (error) {
    console.error('Error guardando progreso:', error);
    // No bloquear la navegación por un error de guardado
  }
};
```

---

## 🚀 Plan de Implementación (Orden Recomendado)

### Fase 1: Fixes Críticos (1-2 horas)

1. **Arreglar `trust proxy`** en `backend/src/index.ts`
2. **Agregar stubs** para rutas 404
3. **Actualizar schema de Prisma** y ejecutar migración

### Fase 2: Conectar Frontend con Backend (2-3 horas)

4. **Verificar que `progressService.ts`** usa las rutas correctas
5. **Integrar en `LessonViewer.jsx`** las llamadas de guardado
6. **Probar flujo completo** con DevTools abierto

### Fase 3: UI del Progreso (1-2 horas)

7. **Agregar barra de progreso** en cards de módulos (curriculum)
8. **Mostrar progreso por nivel** en dashboard
9. **Cargar progreso inicial** al entrar a una lección

---

## 📁 Archivos a Modificar

```
ventylab-server/
├── src/
│   ├── index.ts                    # trust proxy fix
│   ├── middleware/rateLimiter.ts   # validate: { trustProxy: false }
│   ├── routes/progress.ts          # agregar stubs
│   ├── controllers/progress.controller.ts  # implementar stubs
│   └── services/progress.service.ts        # verificar columnas
├── prisma/
│   └── schema.prisma               # agregar campos

ventylab/
├── src/
│   ├── components/teaching/
│   │   └── LessonViewer.jsx        # agregar llamadas API
│   ├── services/
│   │   └── progressService.ts      # verificar endpoints
│   └── hooks/
│       └── useProgress.ts          # verificar hooks
```

---

## 🧪 Cómo Probar

1. Abrir DevTools → Network
2. Entrar a una lección
3. Dar click en "Siguiente" varias veces
4. Verificar que se envían peticiones PUT a `/api/progress/lesson/:lessonId`
5. Verificar que las respuestas son 200
6. Salir de la lección y volver a entrar
7. Verificar que inicia en la sección donde quedó

---

## 🔧 Automatización de Prisma

Para que no tengas que ejecutar migraciones manualmente, agregar en `package.json` del backend:

```json
{
  "scripts": {
    "dev": "prisma generate && prisma migrate deploy && tsx watch src/index.ts",
    "start": "prisma generate && prisma migrate deploy && node dist/index.js",
    "postinstall": "prisma generate"
  }
}
```

**Nota:** `migrate deploy` es para producción (solo aplica migraciones existentes). 
Para desarrollo local, usa `migrate dev` que además crea nuevas migraciones.

---

## ⚠️ Importante

El modelo `Progress` actual mezcla progreso de **lecciones** y **módulos** en la misma tabla. Esto puede funcionar pero requiere cuidado:

- Cuando `lessonId` está presente → Es progreso de una lección
- Cuando `moduleId` está presente y `lessonId` es null → Es progreso agregado del módulo

Alternativa más limpia sería tener dos tablas: `LessonProgress` y `ModuleProgress`, pero eso requiere más cambios. Para el deadline, la tabla unificada funciona.