# 🚀 GUÍA RÁPIDA: Solucionar Sistema de Progreso VentyLab

## ⏱️ Tiempo estimado: 2-3 horas

---

## PASO 1: Fix del Backend (30 min)

### 1.1 Trust Proxy
Abrir `ventylab-server/src/index.ts`:
```typescript
// Buscar:
app.set('trust proxy', true);

// Cambiar a:
app.set('trust proxy', 1);
```

### 1.2 Rate Limiter
Abrir `ventylab-server/src/middleware/rateLimiter.ts` y agregar a cada limiter:
```typescript
validate: { trustProxy: false }
```

### 1.3 Agregar Rutas Faltantes
Abrir `ventylab-server/src/routes/progress.ts` y agregar antes del export:
```typescript
router.get('/milestones', progressController.getMilestones);
router.get('/achievements', progressController.getAchievements);
router.get('/skills', progressController.getSkills);
```

### 1.4 Agregar Controllers
Abrir `ventylab-server/src/controllers/progress.controller.ts` y agregar al final:
```typescript
export async function getMilestones(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = req.headers['x-user-id'] as string || (req.user as any)?.id;
    if (!userId) return res.status(401).json({ error: 'Usuario no autenticado' });
    res.json({ milestones: [], totalCompleted: 0, totalAvailable: 0 });
  } catch (error) { next(error); }
}

export async function getAchievements(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = req.headers['x-user-id'] as string || (req.user as any)?.id;
    if (!userId) return res.status(401).json({ error: 'Usuario no autenticado' });
    res.json({ achievements: [], totalUnlocked: 0 });
  } catch (error) { next(error); }
}

export async function getSkills(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = req.headers['x-user-id'] as string || (req.user as any)?.id;
    if (!userId) return res.status(401).json({ error: 'Usuario no autenticado' });
    res.json({ skills: [], overallLevel: 'beginner' });
  } catch (error) { next(error); }
}
```

---

## PASO 2: Actualizar Schema de Prisma (15 min)

### 2.1 Modificar el modelo Progress
Abrir `ventylab-server/prisma/schema.prisma` y reemplazar el modelo Progress:

```prisma
model Progress {
  id                   String    @id @default(cuid())
  userId               String
  moduleId             String?
  lessonId             String?
  currentStep          Int       @default(0)
  totalSteps           Int       @default(1)
  completed            Boolean   @default(false)
  completionPercentage Float     @default(0)
  progress             Float     @default(0)
  timeSpent            Int       @default(0)
  scrollPosition       Float?
  lastViewedSection    String?
  lastAccess           DateTime?
  completedAt          DateTime?
  createdAt            DateTime  @default(now())
  updatedAt            DateTime  @updatedAt

  user User @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@unique([userId, lessonId], name: "progress_user_lesson_unique")
  @@unique([userId, moduleId], name: "progress_user_module_unique")
  @@index([userId])
  @@index([lessonId])
  @@index([moduleId])
  @@map("progress")
}
```

### 2.2 Aplicar la migración
```bash
cd ventylab-server
npx prisma migrate dev --name fix_progress_model
npx prisma generate
```

**Si hay errores de constraint**, ejecutar:
```bash
npx prisma migrate reset --force
```
⚠️ Esto borra los datos de desarrollo.

---

## PASO 3: Fix del Frontend (1 hora)

### 3.1 Crear hook de guardado
Crear archivo `ventylab/src/hooks/useLessonProgressSave.js`:

```javascript
import { useCallback, useRef, useEffect } from 'react';
import { updateLessonProgress } from '@/services/api/progressService';

export function useLessonProgressSave(lessonId, moduleId, totalSections, options = {}) {
  const { debounceMs = 2000 } = options;
  const saveTimeoutRef = useRef(null);
  const startTimeRef = useRef(Date.now());

  useEffect(() => {
    return () => {
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    };
  }, []);

  const getTimeSpent = useCallback(() => {
    const elapsed = Math.round((Date.now() - startTimeRef.current) / 1000);
    startTimeRef.current = Date.now();
    return elapsed;
  }, []);

  const saveProgress = useCallback(async (currentIndex, immediate = false) => {
    if (!lessonId) return;
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);

    const doSave = async () => {
      const completionPercentage = Math.round(((currentIndex + 1) / totalSections) * 100);
      await updateLessonProgress({
        lessonId,
        completionPercentage,
        timeSpentDelta: getTimeSpent(),
        completed: completionPercentage >= 100,
      });
    };

    if (immediate) return doSave();
    saveTimeoutRef.current = setTimeout(doSave, debounceMs);
  }, [lessonId, totalSections, debounceMs, getTimeSpent]);

  return { saveProgress, saveImmediately: (idx) => saveProgress(idx, true) };
}
```

### 3.2 Integrar en LessonViewer
Abrir `ventylab/src/components/teaching/LessonViewer.jsx`:

```javascript
// Agregar import
import { useLessonProgressSave } from '@/hooks/useLessonProgressSave';

// Dentro del componente, después de los useState:
const totalSections = lesson?.sections?.length || 1;
const { saveProgress, saveImmediately } = useLessonProgressSave(
  lessonId, moduleId, totalSections
);

// Modificar handleNextSection:
const handleNextSection = () => {
  if (currentSectionIndex < totalSections - 1) {
    const newIndex = currentSectionIndex + 1;
    setCurrentSectionIndex(newIndex);
    saveProgress(newIndex); // <-- AGREGAR ESTO
  }
};

// Modificar handleClose (o crear si no existe):
const handleClose = async () => {
  await saveImmediately(currentSectionIndex);
  onClose?.();
};
```

---

## PASO 4: Probar (15 min)

### 4.1 Verificar en consola del navegador
1. Abrir DevTools → Network
2. Entrar a una lección
3. Navegar con "Siguiente"
4. Verificar requests PUT a `/api/progress/lesson/...`
5. Las respuestas deben ser 200

### 4.2 Verificar persistencia
1. Avanzar hasta sección 5/10
2. Cerrar la lección
3. Volver a abrir la misma lección
4. Debe iniciar en sección 5/10 (o cercana)

### 4.3 Verificar en BD
```bash
cd ventylab-server
npx prisma studio
```
Abrir la tabla `progress` y verificar que hay registros con los datos correctos.

---

## PASO 5: Automatizar (Opcional pero recomendado)

### 5.1 Scripts en package.json del backend
```json
{
  "scripts": {
    "dev": "prisma generate && tsx watch src/index.ts",
    "start": "prisma migrate deploy && node dist/index.js",
    "postinstall": "prisma generate"
  }
}
```

---

## 🆘 Si algo falla

### Error de constraint en upsert
Verificar que el servicio usa el nombre correcto:
```typescript
where: {
  progress_user_lesson_unique: { userId, lessonId }
}
```

### Error de columnas desconocidas
Regenerar el cliente después de migrar:
```bash
npx prisma generate
```

### Frontend no envía requests
1. Verificar imports de progressService
2. Verificar que el hook se llama dentro de un componente React
3. Revisar la consola por errores de autenticación

### 404 sigue apareciendo
1. Reiniciar el servidor backend
2. Verificar que las rutas están agregadas ANTES del export del router

---

## 📞 Checklist Final

- [ ] Trust proxy cambiado a `1`
- [ ] Validate agregado a rate limiters
- [ ] 3 rutas nuevas agregadas (/milestones, /achievements, /skills)
- [ ] 3 controllers nuevos agregados
- [ ] Schema de Progress actualizado
- [ ] Migración aplicada sin errores
- [ ] Hook useLessonProgressSave creado
- [ ] LessonViewer modificado para usar el hook
- [ ] Probado en browser con DevTools
- [ ] Progreso se persiste al recargar

---

**¡Listo!** Si sigues estos pasos en orden, el sistema de progreso debería funcionar completamente.